package com.iiuc.cse.b58.s3f.g5.iiuc_course_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IiucCourseApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
