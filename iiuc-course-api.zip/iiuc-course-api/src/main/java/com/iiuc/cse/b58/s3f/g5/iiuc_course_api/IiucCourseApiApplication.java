package com.iiuc.cse.b58.s3f.g5.iiuc_course_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IiucCourseApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(IiucCourseApiApplication.class, args);
	}

}
